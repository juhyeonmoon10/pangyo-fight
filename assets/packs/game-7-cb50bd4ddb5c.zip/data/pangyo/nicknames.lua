-- Personal HUD names. Character identities and network state remain separate.
-- UTF-8 players.txt: line 1 = host / 1P, line 2 = guest / 2P.
-- Online opponents must set the same two names locally; names are not synchronized.
local M = {path = 'data/pangyo/players.txt', names = {'1P 도전자', '2P 도전자'}}
local defaults = {'1P 도전자', '2P 도전자'}
local sprites = {}
local outlines = {}
local font = fontNew('pangyo/hud.def')

-- Keep at most 16 valid Unicode characters; do not split a Korean syllable.
local function clean(value, fallback)
  value = (value or ''):gsub('^\239\187\191', ''):gsub('%c', '')
  value = value:match('^%s*(.-)%s*$') or ''
  local out, count, i = {}, 0, 1
  while i <= #value and count < 16 do
    local first = value:byte(i)
    local size = first < 128 and 1 or (first >= 194 and first <= 223 and 2
      or (first >= 224 and first <= 239 and 3 or (first >= 240 and first <= 244 and 4 or 0)))
    local valid = size > 0 and i + size - 1 <= #value
    for j = 1, size - 1 do
      local b = value:byte(i + j)
      if not b or b < 128 or b > 191 then valid = false end
    end
    if valid and size >= 3 then
      local second = value:byte(i + 1)
      if (first == 224 and second < 160) or (first == 237 and second >= 160)
        or (first == 240 and second < 144) or (first == 244 and second >= 144) then
        valid = false
      end
    end
    if valid then
      out[#out + 1] = value:sub(i, i + size - 1)
      count, i = count + 1, i + size
    else
      i = i + 1
    end
  end
  local result = table.concat(out):match('^%s*(.-)%s*$') or ''
  return result ~= '' and result or fallback
end

for side = 1, 2 do
  local text = textImgNew()
  textImgSetFont(text, font)
  -- Draw(layer) still requires the sprite's own layerno to match that layer.
  textImgSetLayerno(text, 2)
  textImgSetLocalcoord(text, 1280, 720)
  textImgSetPos(text, side == 1 and 112 or 1168, 44)
  textImgSetAlign(text, side == 1 and 1 or -1)
  textImgSetColor(text, 255, 244, 212, 255)
  sprites[side] = text
  outlines[side] = {}
  for _, offset in ipairs({{-2,-2},{2,-2},{-2,2},{2,2}}) do
    local shadow = textImgNew()
    textImgSetFont(shadow, font)
    textImgSetLayerno(shadow, 2)
    textImgSetLocalcoord(shadow, 1280, 720)
    textImgSetPos(shadow, (side == 1 and 112 or 1168) + offset[1], 44 + offset[2])
    textImgSetAlign(shadow, side == 1 and 1 or -1)
    textImgSetColor(shadow, 7, 11, 24, 255)
    outlines[side][#outlines[side] + 1] = shadow
  end
end

function M.reload()
  local lines = {}
  local file = io.open(M.path, 'rb')
  if file then
    -- Bound the amount read if the file was edited by hand or is malformed.
    local contents = file:read(4096) or ''
    file:close()
    contents = contents:gsub('\r\n', '\n'):gsub('\r', '\n')
    for line in (contents .. '\n'):gmatch('(.-)\n') do
      lines[#lines + 1] = line
      if #lines == 2 then break end
    end
  end
  for side = 1, 2 do
    M.names[side] = clean(lines[side], defaults[side])
    local text = sprites[side]
    textImgSetText(text, M.names[side])
    textImgSetScale(text, 1, 1)
    local width = textImgGetTextWidth(text, M.names[side])
    local scale = width > 430 and 430 / width or 1
    textImgSetScale(text, scale, scale)
    for _, shadow in ipairs(outlines[side]) do
      textImgSetText(shadow, M.names[side])
      textImgSetScale(shadow, scale, scale)
    end
  end
end

M.reload()
hook.add('launchFight', 'pangyo_personal_names_reload', M.reload)
hook.add('loop', 'pangyo_personal_names_draw', function()
  if roundState() < 0 then return end
  for side = 1, 2 do
    for _, shadow in ipairs(outlines[side]) do textImgDraw(shadow, 2) end
  end
  textImgDraw(sprites[1], 2)
  textImgDraw(sprites[2], 2)
end)

return M
