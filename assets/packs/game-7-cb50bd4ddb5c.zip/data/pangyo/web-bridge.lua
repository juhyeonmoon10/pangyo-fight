-- The page establishes WebRTC first. Native menu synchronization and character
-- selection then run through the existing engine's server host/join functions.
local ready = false
local entered = false
local function signal()
  if not ready then ready = true; print('PANGYO_READY') end
end
hook.add('main.menu.loop', 'pangyo_web_ready', function()
  signal()
  if entered then return end
  local role = getCommandLineValue('-webnet')
  if role ~= 'host' and role ~= 'guest' then return end
  -- The synchronized server menu invokes this same hook: guard before entering.
  entered = true
  print('PANGYO_WEBNET_ENTER ' .. role)
  -- Normal menu selection initializes these mode tables before dispatching an
  -- item. This boot hook runs earlier, so mirror that initialization explicitly.
  main.f_default()
  if role == 'host' then
    main.t_itemname.serverhost({{itemname = 'serverhost', displayname = '브라우저 상대'}}, 1)
  else
    modifyGameOption('Netplay.IP.pangyo_rtc', '192.0.2.1')
    main.t_itemname.serverconnect({{itemname = 'ip_pangyo_rtc', displayname = '브라우저 상대'}}, 1)
  end
  print('PANGYO_WEBNET_EXIT ' .. role)
end)
hook.add('loop', 'pangyo_web_fight_ready', signal)
return {}
