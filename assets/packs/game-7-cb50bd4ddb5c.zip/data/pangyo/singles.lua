-- Pangyo is individual one-versus-one in every selectable mode.
hook.add('main.t_itemname', 'pangyo_single_only', function()
  for side = 1, 2 do
    main.teamMenu[side] = {single = true, simul = false, tag = false, turns = false}
  end
end)
hook.add('start.selectScreen.teamMenu', 'pangyo_single_only', function(side, items)
  for i = #items, 1, -1 do
    if items[i].itemname ~= 'single' then table.remove(items, i) end
  end
end)
local nicknameFile = io.open('data/pangyo/nicknames.lua', 'r')
if nicknameFile then
  nicknameFile:close()
  require('data.pangyo.nicknames')
end
